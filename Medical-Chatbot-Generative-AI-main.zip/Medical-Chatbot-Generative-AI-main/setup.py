from setuptools import setup, find_packages

setup(
    name="MedicalChatbot",
    version="0.1",
    author_email= 'sc9100@srmist.edu.in',
    packages=find_packages(),
    install_requires=[],
)
